package org.example;

import java.awt.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        //Ventana ventana=new Ventana("Layouts");
        VentanaGrid ventanaGrid=new VentanaGrid("Ventana Layout Cuadricula");

    }
}